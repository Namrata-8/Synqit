package com.example.synqit.fragments.businessfragment3;

public interface BusinessFragment3Navigator {

    void goContinue();

    void onCountryClick();
}
