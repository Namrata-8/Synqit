package com.example.synqit.ui.support;

public interface SupportNavigator {
    void onAddTicketClick();
    void onBackClick();
}
