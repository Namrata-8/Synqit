package com.example.synqit.ui.otpverification.model;

public class ParamGetOtp {
    private String email;

    public ParamGetOtp(String email) {
        this.email = email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
