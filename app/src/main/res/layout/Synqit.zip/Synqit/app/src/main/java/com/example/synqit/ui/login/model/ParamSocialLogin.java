package com.example.synqit.ui.login.model;

public class ParamSocialLogin {
    private String token;

    public ParamSocialLogin(String token) {
        this.token = token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
