package com.example.synqit.ui.membership;

import androidx.lifecycle.ViewModel;

public class MembershipViewModel extends ViewModel {
    public MembershipViewModel() {
    }
}
