package com.example.synqit.ui.resetpass.model;

public class ParamResetPass {
    private String userID;
    private String password;

    public ParamResetPass(String userID, String password) {
        this.userID = userID;
        this.password = password;
    }
}
