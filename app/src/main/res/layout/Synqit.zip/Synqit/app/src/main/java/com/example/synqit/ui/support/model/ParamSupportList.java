package com.example.synqit.ui.support.model;

public class ParamSupportList {
    private String parentUserID;

    public ParamSupportList(String parentUserID) {
        this.parentUserID = parentUserID;
    }

    public void setParentUserID(String parentUserID) {
        this.parentUserID = parentUserID;
    }
}
