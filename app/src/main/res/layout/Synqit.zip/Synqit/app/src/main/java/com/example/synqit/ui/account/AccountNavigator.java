package com.example.synqit.ui.account;

public interface AccountNavigator {
    void onBackClick();

    void onGenderClick();

    void onCountryClick();

    void onContinueClick();

    void onDateClick();
}
