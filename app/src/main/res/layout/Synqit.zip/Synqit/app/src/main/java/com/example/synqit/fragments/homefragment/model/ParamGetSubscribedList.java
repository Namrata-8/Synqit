package com.example.synqit.fragments.homefragment.model;

public class ParamGetSubscribedList {
    private String userId;

    public ParamGetSubscribedList(String userId) {
        this.userId = userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
