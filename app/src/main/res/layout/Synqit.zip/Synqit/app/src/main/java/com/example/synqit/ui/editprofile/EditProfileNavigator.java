package com.example.synqit.ui.editprofile;

public interface EditProfileNavigator {
    void selectBlack();
    void selectBlue();
    void selectPink();
    void selectRed();
    void selectOrange();
    void selectYellow();
    void selectGreen();
    void selectWhite();
    void onSaveChange();
    void onBack();
    void onView();
}
