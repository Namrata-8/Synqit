package com.example.synqit.ui.register;

public interface RegisterNavigator {

    void goToLogin();

    void goToOtpVerification();

    void goToBack();

    void onApple();
    void onGoogle();
    void onFacebook();
}
