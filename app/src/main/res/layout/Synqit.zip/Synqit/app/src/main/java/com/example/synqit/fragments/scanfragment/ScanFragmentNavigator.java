package com.example.synqit.fragments.scanfragment;

public interface ScanFragmentNavigator {
}
