package com.example.synqit.ui.createconnection;

public interface CreateConnectionNavigator {
    void goToBack();
    void uploadCoverImg();
    void uploadProfileImg();
    void onClickSocialMedia();
    void onCreateConnection();
}
