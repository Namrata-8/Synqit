package com.example.synqit.fragments.connectionsfragment.model;

public class ParamGetConnection {

    private String parentUserID;

    public ParamGetConnection(String parentUserID) {
        this.parentUserID = parentUserID;
    }

    public void setParentUserID(String parentUserID) {
        this.parentUserID = parentUserID;
    }
}
