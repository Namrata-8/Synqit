package com.example.synqit.ui.resetpass;

public interface ResetPassNavigator {
    void goToBack();
    void resetPassword();
}
