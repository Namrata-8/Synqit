package com.example.synqit.ui.dashboard.model;

public class ParamGetCard {
    private String parentUserID;

    public ParamGetCard(String parentUserID) {
        this.parentUserID = parentUserID;
    }

    public void setParentUserID(String parentUserID) {
        this.parentUserID = parentUserID;
    }
}
