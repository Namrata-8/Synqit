package com.example.synqit.ui.forgotpass;

public interface ForgotPassNavigator {
    void goToBack();
    void verifyUser();
}
