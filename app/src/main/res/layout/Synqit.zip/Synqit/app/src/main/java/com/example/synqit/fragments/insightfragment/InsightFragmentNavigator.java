package com.example.synqit.fragments.insightfragment;

public interface InsightFragmentNavigator {
}
