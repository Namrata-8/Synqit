package com.example.synqit.fragments.connectionsfragment;

public interface ConnectionsFragmentNavigator {
}
