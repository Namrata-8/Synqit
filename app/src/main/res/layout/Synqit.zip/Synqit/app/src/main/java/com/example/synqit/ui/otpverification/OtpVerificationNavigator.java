package com.example.synqit.ui.otpverification;

public interface OtpVerificationNavigator {
}
