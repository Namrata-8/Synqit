package com.example.synqit.ui.proupgrade;

public interface ProUpgradeNavigator {

    void onContinue();

    void onBack();
}
