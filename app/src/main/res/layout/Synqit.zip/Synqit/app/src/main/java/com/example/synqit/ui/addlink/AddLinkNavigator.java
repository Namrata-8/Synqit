package com.example.synqit.ui.addlink;

public interface AddLinkNavigator {
    void goToBack();
}
