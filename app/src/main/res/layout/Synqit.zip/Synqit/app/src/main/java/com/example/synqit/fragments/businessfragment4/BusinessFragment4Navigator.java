package com.example.synqit.fragments.businessfragment4;

public interface BusinessFragment4Navigator {

    void addLogo();

    void uploadCoverPhoto();

    void onFinish();

    void onSkipNow();
}
