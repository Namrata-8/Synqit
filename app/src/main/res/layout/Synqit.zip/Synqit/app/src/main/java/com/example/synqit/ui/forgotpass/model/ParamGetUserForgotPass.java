package com.example.synqit.ui.forgotpass.model;

public class ParamGetUserForgotPass {
    private String username;

    public ParamGetUserForgotPass(String username) {
        this.username = username;
    }
}
