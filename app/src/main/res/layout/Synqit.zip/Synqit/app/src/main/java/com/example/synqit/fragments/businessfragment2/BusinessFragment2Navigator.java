package com.example.synqit.fragments.businessfragment2;

public interface BusinessFragment2Navigator {
    void onContinueClick();
}
