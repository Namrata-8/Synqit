package com.example.synqit.fragments.businessfragment4.model;

import com.google.gson.annotations.SerializedName;

public class AddImageData {
    @SerializedName("fileUrl")
    private String fileUrl;

    public String getFileUrl() {
        return fileUrl;
    }
}
