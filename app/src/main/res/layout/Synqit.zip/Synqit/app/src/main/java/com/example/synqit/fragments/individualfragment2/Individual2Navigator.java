package com.example.synqit.fragments.individualfragment2;

public interface Individual2Navigator {

    void goContinue();

    void onCountryClick();

    void onGenderClick();

    void onDateClick();
}
