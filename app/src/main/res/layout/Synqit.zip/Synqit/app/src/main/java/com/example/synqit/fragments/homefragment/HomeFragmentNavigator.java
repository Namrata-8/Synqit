package com.example.synqit.fragments.homefragment;

public interface HomeFragmentNavigator {
    void gotoAddLink();
}
